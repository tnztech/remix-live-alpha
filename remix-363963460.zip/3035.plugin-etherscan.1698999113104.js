"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([[3035],{

/***/ 63035:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("REMIX CIRCOM WORKSPACE\n\nWelcome to the Remix Circom Workspace. This workspace becomes available when you create a new workspace using the 'Circom' template.\nDirectory Structure\n\nThe workspace comprises two main directories:\n\n    circuits: Contains sample semaphore contracts. These can be compiled to generate a witness.\n    scripts: Provides a sample script designed for a trusted setup using snarkjs. This script also aids in generating Solidity code, which is essential for on-chain deployment.");

/***/ })

}]);
//# sourceMappingURL=3035.plugin-etherscan.1698999113104.js.map