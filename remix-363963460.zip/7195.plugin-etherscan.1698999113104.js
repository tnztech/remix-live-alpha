"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([[7195],{

/***/ 7195:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("// SPDX-License-Identifier: LGPL-3.0-only\npragma solidity >=0.7.0 <0.9.0;\n\nimport \"@gnosis.pm/safe-contracts@1.3.0/contracts/GnosisSafe.sol\";\n\ncontract MultisigWallet is GnosisSafe {}");

/***/ })

}]);
//# sourceMappingURL=7195.plugin-etherscan.1698999113104.js.map